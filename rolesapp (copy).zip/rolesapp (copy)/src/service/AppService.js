import axios from 'axios';

const url = "http://localhost:8080/apps";


 class AppService{

     getApps(){

         return axios.get(url)

     }


 }

 export default new AppService();