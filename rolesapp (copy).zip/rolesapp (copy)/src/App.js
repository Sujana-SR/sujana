import logo from './logo.svg';
import './App.css';
import RoleComponent from './component/Rolecomponent';
import Sidebar from './component/sidebar';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

import AddRoleComponent from './component/AddRoleComponent';
import 'bootstrap/dist/css/bootstrap.min.css';

import 'bootstrap/dist/js/bootstrap.bundle.min';

import 'bootstrap-icons/font/bootstrap-icons.css';
import Topnav from './component/topnav';





function App() {



  return (
    

   
  
  
<Router>
{/* <Topnav></Topnav> */}
<div>
  
      <Sidebar/> 
     
      <Switch>
    
         {/* <Route exact path="/" component={Sidebar}/> */}
         {/* <Route exact path="/roles" component={RoleComponent}/> */}
         <Route exact path="/roles" component={RoleComponent} />
         <Route  path="/addrole" component={AddRoleComponent} />
         
  </Switch> 

  {/* <div>
  <RoleComponent></RoleComponent>
    </div> */}
    </div>
   </Router>
 
  
   
   
  );
}

export default App;
