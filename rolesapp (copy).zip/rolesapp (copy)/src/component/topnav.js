import React, { Component } from 'react';
import '../component/page.css';
import a from '../assets/imgs/others/a.png';

class Topnav extends Component {
    constructor(props) {
        super(props);
        this.state = {}}
        render(){ return(
                <div className='rows'>
                    <div class="topnav">
                    <a class="navbar-brand" href="">
                    <img src={a} className="img"
                     height="40px"
                     width="40px"/></a>
                    <a ><p class="pt-3"><b>ADMINISTRATION</b></p></a>
                    <a style={{position:"relative",bottom:"10px",paddingRight:"15px",float:"right"}}> <i id="icon" class="fa fa-user ms-auto" aria-hidden="true"></i></a>
                    </div>
                </div>
        )}
           
        }
export default Topnav;


