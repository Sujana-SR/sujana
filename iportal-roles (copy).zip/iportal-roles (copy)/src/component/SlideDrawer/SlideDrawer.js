import React,{useState} from 'react'
import './SlideDrawer.css'
// import RoleComponent from '../RolesComponent/Rolecomponent';
import Skeleton from 'react-loading-skeleton';

import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
// import AdminService from '../service/AdminService';
// import AppService from '../service/AppService';
import AppService from '../AppComponent/AppService';
import AdminService from '../AdminComponent/AdminService';
import { Link } from 'react-router-dom'

export default class SlideDrawer extends React.Component {

   constructor(props){
      super(props)
      this.state={
          apps:[],
          admins:[],
        
      }
     
  }
  componentDidMount(){
      AppService.getApps().then((response)=>{
          this.setState({apps:response.data})

      });
       AdminService.getAdmins().then((response)=>{
            this.setState({admins:response.data})

        });
  }
     
 

   render(){
   //    const getRoles = async (id) => {
      
      
   //       const response = await fetch(`http://localhost:8080/admin/${id}`);
   //   console.log( await response.json());
      
       
   //   }
  
    

       let drawerClasses = 'side-drawer'
       if(this.props.show) {
          drawerClasses = 'side-drawer open'
         //  let id =localStorage.getItem("roleid")
         //  getRoles(id);
          
       }   
       
       
      
       return(
   
//           <div className={drawerClasses}>
//              {/* <h1>{this.roles }</h1> */}
// {/* {RoleComponent.state.roleid} */}
//           </div>)


<div className={drawerClasses}>


<br/>
<br/>
<br/>
<h3 className='rolename'>&ensp; &ensp; {localStorage.getItem('role')}</h3>
<br/>
<br/>
<Tabs>
<TabList className="tab">
<Tab style={{border:"none"}}>Application Access</Tab>
<Tab style={{border:"none"}}>Assigned Admins</Tab>
</TabList>

<TabPanel>
<div className="Apps">

<table className="table table-borderless">
<thead>
<tr>
   {/* <td>Id</td>
   <td className='td'>Application Access</td>
   <td></td> */}
   
  
</tr>
</thead>
<tbody>
{
   this.state.apps.map(
       app =>
       <tr key={app.id}>
           {/* <td>{role.id}</td> */}
           <td className='td'><i class='fas fa-check'></i>&nbsp; &nbsp;{app.name}</td>
          

       </tr>

   )
}
&nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;<Link className='link'>Show More (7)</Link>
</tbody>
</table>

</div>
</TabPanel>
<TabPanel>
<div className="Admin">
<Link className='link'>+ Add Admin</Link>
 
 <table className="table table-borderless">
     
     <thead>
         <tr>
             {/* <td>Id</td> */}
             <td className='bld'>Admin</td>
             <td className='bld'>Last sign-in</td>
             <td></td>
             
            
         </tr>
     </thead>
     <tbody>
         {
             this.state.admins.map(
                 admin =>
                 <tr key={admin.id}>
                     {/* <td>{role.id}</td> */}
                     <td className='td'>{admin.adminname}</td>
                     <td className='td'>{admin.lastseen}</td>

                 </tr>

             )
         }
     </tbody>
 </table>

</div>

</TabPanel>
</Tabs>
  



</div>
       )
      }

    
}