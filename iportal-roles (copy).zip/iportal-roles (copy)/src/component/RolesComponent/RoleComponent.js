import React, { useState } from 'react';
// import Roleservice from "../service/Roleservice";
import RoleService from "./RoleService";
import "./RoleComponent.css";
import { Link } from 'react-router-dom';
// import Sidebar from '../sidebar/sidebar';
// import Backdrop from '../sidebar/Backdrop';
// import SlideDrawer from '../sidebar/SlideDrawer';
import SlideDrawer from '../SlideDrawer/SlideDrawer';
import Backdrop from '../SlideDrawer/Backdrop';

import { VscAccount,VscCircleSlash } from "react-icons/vsc";



class RoleComponent extends React.Component{
    state = { drawerOpen: false, roles:[]}
    

    drawerToggleClickHandler = (role) => {
   

        this.setState({
          drawerOpen: !this.state.drawerOpen,
        

        })
        localStorage.setItem("role",role)
        
      }
       sideHandler = (id) =>
       {
           
      }
      backdropClickHandler = () => {
        this.setState({

          drawerOpen: false
        })
      }
     
    componentDidMount(){

        RoleService.getRoles().then((response)=>{

            this.setState({roles:response.data})
            localStorage.setItem("this.state.roleid",JSON.stringify(this.state.roles.id))



        });

    }


    render(){
        let backdrop;
      if(this.state.drawerOpen){
        backdrop = <Backdrop close={this.backdropClickHandler}/>;
       }
      
     
       
        return(

          
          

            <div className="roles">
              <div id="demo">

        
              
               <p>Home &gt;   Roles</p>
              
               <br></br><br></br>
                <h1 className="">Roles</h1>
                {/* <Link to = "/addrole" className = "btn btn-primary mb-2"> ADD ROLE </Link> */}
                <hr></hr>

                <div>

               

<p style={{fontSize:"13px"}}><Link to="/addrole"><VscAccount></VscAccount></Link>

<a> </a>Add Role <a style={{color:"rgb(240, 236, 236)"}}> ii</a> <Link to=""><VscCircleSlash></VscCircleSlash></Link> Delete Role                   <a>&emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;&emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;   </a><i style={{color:"#87CEEB"}} class='fa fa-search'></i ><a>&nbsp; &nbsp;</a>
< input className="search" type="text" id="input-search" name="search" placeholder="Search roles"  /> <i class="fa fa-bars" aria-hidden="true"></i></p>

               

                 

 

                </div>
                <br></br><br></br>

                <table className="table">

                    <thead>

                        <tr>

                            {/* <td>Id</td> */}

                            <td>User roles</td>

                            <td></td>

                            <td>Description</td>

                           

                        </tr>

                    </thead>
                  
<tbody>


    { this.state.roles.map(

        role => <tr key={role.id}> 
        {/* <td>{role.id}</td> */}
        {/* <i class="fa-solid fa-circle-check"></i> */}
       
         <td> 
         <SlideDrawer show={this.state.drawerOpen}
         />
        
        <SlideDrawer rid={this.state.roleid}/>
             { backdrop } 
       
             <input className='col'
             
      type="button"
      value={role.role}
      onClick={() =>  this.drawerToggleClickHandler(role.role)}
   

    
    />
  
  {/* {this.state.roleid} */}
         
         </td> <td>:</td> <td className='des'>
           {role.description}</td>
          </tr>) 
          } 
          </tbody>
           </table>
           </div>
            </div>) 
            }
        }
export default RoleComponent;

